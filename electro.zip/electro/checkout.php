<?php
$conn=mysqli_connect("localhost","root","","electro");
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$email=$_POST["email"];
$addr=$_POST["addr"];
$city=$_POST["city"];
$country=$_POST["country"];
$zip=$_POST["zip"];
$tel=$_POST["tel"];
$check=mysqli_query($conn,"SELECT * FROM chekouttable WHERE Email='$email'");
$data=mysqli_fetch_array($check,MYSQLI_NUM);

if($data>1)
{
	echo"user mail already exits!..";

}
else{


$result=mysqli_query($conn,"INSERT INTO checkouttable(Firstname,Lastname,Email,Address,City,Country,Zipcode,Tel)
           VALUES('$fname','$lname','$email','$addr','$city','country','$zip','tel');");

if($result)
{
	
echo "<script>alert('Details Updated');</script>";

header("location:index.html");

}
}

?>
